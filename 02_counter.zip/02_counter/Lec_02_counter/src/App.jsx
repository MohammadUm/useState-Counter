import { useState } from 'react'
import reactLogo from './assets/react.svg'
import viteLogo from '/vite.svg'
import './App.css'

function App() {
 const[Counter,setCounter]=useState(15)
//useState is used to change the state|useState()-> default value can be given anything as a parameter
//0th index value will be counter and 2nd value is a Function which is Setcounter
 let counter=15;
const addValue=()=>{
  setCounter(Counter + 1)//update the counter using set counter//hum call kre hai 
  console.log("Clicked",Counter)
}
const decreaseValue=()=>{
  setCounter(Counter - 1)//decrease the counter
}

return (
  <>
    <h1>Chai aur code</h1>
    <h2>Counter value {Counter}</h2>
    <button onClick={addValue}>Add value</button>
    <button onClick={decreaseValue}>Decrease value</button>
  </>
)
 }


export default App
 